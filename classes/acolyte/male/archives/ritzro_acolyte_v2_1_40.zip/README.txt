RitzRO male Acolyte custom palettes v2, 1-40

Generated from the known-good Acolyte v5 binary baseline. Fourth bytes and untouched entries are preserved.

Current Acolyte mapping used:
  Primary robe: 73-79
  Secondary frock: 9,11,12,14,15
  Shared index 56: role-aware Secondary shadow / Primary detail, with selected intentional overrides
  Tertiary cuffs/trousers: 49-55 + 13
  Quaternary gloves/shoes: 1-2,10,16-23,25-31,65,66,68
  Outline: 43-48
  Belt: 81-89, Secondary-derived
  Preserved: 8; 34,36,37,39,40; 70-72

Key v2 design lessons:
  - index 56 is usually a dark Secondary shadow that can also read as a subtle Primary detail
  - index 56 may intentionally become a vivid contrasting highlight when the whole composition supports it (style 7)
  - gloves/shoes are not restricted to brown leather; their color is part of the overall composition
  - dark garments retain readable value ramps instead of collapsing to flat black
  - adjacent garment families are separated by hue, value, saturation, or material character

Design groups:
  1-10  reimagined originals
 11-20  grounded / realistic
 21-30  fluorescent experiments
 31-40  wild cards

 1: Crimson Cleric       | P #15161A | S #E51F43 | T #F2C23A | Q #7A2634 | 56 #4C1722 | SHA256 04365ff8d3ea2b1b610d83bc29661717e000c7fe2744f24b62ab694b6c66f734
 2: Cobalt Cleric        | P #14161B | S #2478F2 | T #E5B144 | Q #2A4B78 | 56 #132C56 | SHA256 ccfc7123301eebe061d6081aff52e828f523b440acf8fb9083c797e1cae59625
 3: Emerald Pilgrim      | P #137253 | S #79512F | T #D99642 | Q #633A2A | 56 #3C2A21 | SHA256 9342418dad6471fe53127ac3aa34620e5135bd5b535b56e3f70eb94eb1cd5453
 4: Winter Chapel        | P #59AEE0 | S #F6F0E4 | T #5F88A6 | Q #B98355 | 56 #8B8B89 | SHA256 706b2584f362fb0251d1138d9a2952dd1bcd6bbd8f24d95627bab40f8ed8ce59
 5: Ivory Nocturne       | P #E4D1A5 | S #17191D | T #C48B55 | Q #6F3E58 | 56 #343036 | SHA256 b83ce01175206b73e812d688fd64679681c9664f8cb28292b2f0e882f553534e
 6: Gilded Shadow        | P #15171B | S #50545D | T #F1BF28 | Q #9B7421 | 56 #333840 | SHA256 3c046f1c7ef8185b633e4c7a6130acc08f701e7621daeca4ec7d61a7ce415f8c
 7: Azure Ember          | P #B84617 | S #188CFF | T #188CFF | Q #E56E1F | 56 #2D9CFF | SHA256 5e3f1ee4e36f90b5ffe2695430d86ac2ac7f8c93ca2eb194902bce7e5207c2f9
 8: Violet Monastic      | P #7043AE | S #17191D | T #D8D5EA | Q #55358C | 56 #2D2934 | SHA256 4616b20302704dd28e269ed46ea39be1a3fbfb62376b7f44999cc88b9b2d4940
 9: True Charcoal        | P #1E2126 | S #4B5058 | T #8E98A4 | Q #A05A3E | 56 #333940 | SHA256 6ca8be9d439f4f3c01fe7d25cf06aa195fd16a0a3c3bda6c3875d91a15df811c
10: Scarlet Reliquary    | P #C63843 | S #951C32 | T #F1C12C | Q #5538A4 | 56 #651928 | SHA256 a8c6b9c80f63c3ddd14ca9047aea38c0d32d4569e156177f3a4827931211b844
11: Forest Parish        | P #4D613E | S #304E3D | T #A77B4E | Q #6B4930 | 56 #263B30 | SHA256 68702be64094f40921a6a11ee5a1ae1c4d2c29556ab437101bd5bd068c5ef42e
12: Desert Friar         | P #B99C6E | S #887150 | T #5D4937 | Q #795B40 | 56 #5B4938 | SHA256 a0340170e545611ca656f49d60a58281da2f1c8bbc950c225fc3507416764412
13: Harbor Chaplain      | P #526E86 | S #31495D | T #C08D55 | Q #7D3F32 | 56 #263B4B | SHA256 b41413f7951da82f6a71763bfcac5dfae22b8365d826e93f4b85df56ff5b542f
14: Burgundy Vestment    | P #2B2E34 | S #7D374B | T #B98361 | Q #3C4D62 | 56 #4A2231 | SHA256 886ee12b43012ef45e5633b7f2cf8a9f2f66bb9adceb829a48bc523cbe8bd2ff
15: Moss and Linen       | P #627057 | S #D7CEB0 | T #866447 | Q #365C55 | 56 #716B57 | SHA256 c2926f355c002c1bd32fbc7b67b1c0500d1e373171a6894ab7452af1e9a30329
16: Slate Missionary     | P #2C3138 | S #60798C | T #B1845E | Q #6C3C2F | 56 #3C5262 | SHA256 e6a9e539fc029bedd227b5e2f51b92b1ffbb9ba27568182639d15ba7f6c42245
17: Autumn Parish        | P #685F41 | S #A55230 | T #65412E | Q #425C35 | 56 #653220 | SHA256 b35b7dea4312f2b849bb647eed9d04d80f4002f6ccb7eba227a4aa0f65898ce9
18: Dust Road            | P #877A6A | S #72836B | T #B47A4A | Q #4E6570 | 56 #4F5B49 | SHA256 258a7abe23b395a378ef68405b80b12da8f4e4ecd5f6be5c3a5d186a431d8114
19: Cold Abbey           | P #27394F | S #5B6067 | T #B88D61 | Q #764539 | 56 #35404E | SHA256 8c45c2ce85353a670a454b52051e37510332ea226d2cfde852d91831260f4c18
20: Field Cleric         | P #725842 | S #606B43 | T #3A3D42 | Q #8E6D38 | 56 #3D492F | SHA256 2700e039033d33f149abbac9224de2772e1a922bca4a29e8c8b600b9babc7b93
21: Neon Cyan Rite       | P #102329 | S #00E9FF | T #FF35B4 | Q #FF7A21 | 56 #094A58 | SHA256 ab0ccc35e441d79cb267fdb54bb4271fc88a084a7adfb9cdacaaf52fb2eb632c
22: Acid Magenta         | P #28142F | S #FF28C4 | T #B7FF1F | Q #6F39FF | 56 #4E1763 | SHA256 7412c0823f81829309a3bea71f0e9156db304083bc0255ffd2261367bde1e4a5
23: Toxic Lime           | P #14231A | S #AFFF1C | T #7A35FF | Q #FF4B29 | 56 #406018 | SHA256 c11ebf3f72e74b9cd4deb74ca456f1cc05993468aef4fbe6d279a86ef60edee2
24: Ultraviolet          | P #181223 | S #7D36FF | T #00F2FF | Q #FF4DAA | 56 #35195D | SHA256 f7f1f52110bc6a00d7f9afe45306ba993fe99fa0e0b5436dfd165d0fb9f9b468
25: Laser Orange         | P #171515 | S #FF681D | T #17F0D1 | Q #7B46FF | 56 #6B2A16 | SHA256 fb94a50ad5c26b026bcc4c814a79ed61e9de98dba0a022e5b058d3fc4d639935
26: Electric Blue        | P #10182A | S #168BFF | T #FFD62A | Q #FF5E2E | 56 #123A6B | SHA256 c2cf5816a47b2abbc0aaf370842acf73befb91faf58c73de965ab981fc09416a
27: Radioactive Rose     | P #251019 | S #FF3B7C | T #65FF45 | Q #21D8FF | 56 #5A1730 | SHA256 35a332a081783080b2679d0c77603f96ad67170c7aa813bbc83af70636ddb393
28: Plasma Violet        | P #171120 | S #B323FF | T #FF7A18 | Q #1EE6A8 | 56 #48145F | SHA256 f4243f5cb8df8280f6914ce7c89d03dac571d6cc60dc0e03203edf8e225ce194
29: Signal Green         | P #101F19 | S #25FF89 | T #FF2D59 | Q #9B4DFF | 56 #154B31 | SHA256 5410d818f72145f8566a10c4f0ec4347d5f16e3c1eee1c3d6f32aa53fd9ae7dc
30: Cyber Yellow         | P #1D1C10 | S #F5FF25 | T #2E9DFF | Q #FF3B76 | 56 #5C5514 | SHA256 583d8e0ccea37017bc1c112f0684c362a616475aa6744c905c0e87f2bd6be8d9
31: Royal Peacock        | P #133F47 | S #145FDF | T #E6BB2C | Q #D34C8E | 56 #253B75 | SHA256 53371bc0d70ed6ecf963305e30ef06f1efbcd3dfb70592f421e47afc967c7a42
32: Blood and Bone       | P #19191C | S #C51F31 | T #EEE2CA | Q #6F93C7 | 56 #54151D | SHA256 3af2d81df32c1034cd2d78d589791f4f8fa39eb874d1b0c39ce1f7cb56320f30
33: Copper Storm         | P #39424E | S #D15D2D | T #4AC2D4 | Q #E5B43B | 56 #6C3422 | SHA256 425c1548f0c34d2d613614595fe209fb9afedd4be5aeb14fa92810ec0f0a1cd2
34: Moonlit Orchid       | P #29233C | S #7956E2 | T #E08BD5 | Q #38B8B0 | 56 #3F2C68 | SHA256 218ee2869c04e3713cedf0de8eb85bf76e325e739f4cb0ea9f333cd4ba2264ef
35: Jade Ember           | P #115C4F | S #E34A27 | T #F1C13B | Q #4F86E8 | 56 #66301D | SHA256 aca0197df4b2b169b38893c26bc7cff8551aebdb5a1f010567f1d081d1283a01
36: Rose Gold Night      | P #18171B | S #C34B78 | T #E8AB68 | Q #30C7C0 | 56 #552138 | SHA256 a0f21f27085a52fa1473e9d330123f2d2789a39eaf683b32273c776e75fc9430
37: Icefire              | P #20394F | S #F05A36 | T #7DEEFF | Q #FFB51C | 56 #6B3024 | SHA256 b373ea5997f698d3e7e14c5a0018b878cc164d451b340ac3f5b511b85aa5c887
38: Teal and Wine        | P #153E42 | S #843054 | T #E9B04A | Q #3F86D9 | 56 #462239 | SHA256 387209134f6313619a7d2d4658c1e49fd11456c8f6ddc73fdb9036264bac7cbe
39: Solar Punk           | P #18372B | S #F0D02B | T #22D2AD | Q #F05B49 | 56 #65551A | SHA256 692b36a08b7525391b4d277aa17bac9f718cd2bdd2efb5d3dd232d161b40b14b
40: Black Hot Pink       | P #101014 | S #FF2998 | T #272832 | Q #FF2998 | 56 #66163F | SHA256 79125a44e4642f2a791a592dc227193dd1d45b04649a09d81371116b56d5d856
