RitzRO male Acolyte custom palettes v5
Base: acolyte_male_692.pal

v5 changes:
  index 56 is now a Primary/Secondary bridge color, not a Secondary highlight.
  index 10 moved from Secondary to Quaternary shoe highlight.
  index 13 moved from Secondary to Tertiary dark cuff/glove shadow.
  indices 14-15 remain Secondary (diagnostic ruled them out as robe-bleed source).

Core mapping:
  Primary: 73-79
  Secondary: 9,11,12,14,15
  Primary/Secondary bridge: 56
  Tertiary: 49-55 + 13
  Quaternary: 1-2, 10, 16-23, 25-31, 65,66,68
  Outline: 43-48
  Belt accessory: 81-89 (Secondary-derived)
  Preserved: 8; 34,36,37,39,40; 70-72

 1: Black / Crimson | P #151619 | S #8E1831 | T #B21F3D | Q #3B2024 | bridge56 #401922 | SHA256 6cbca6c53fe83f0f1969169337a87b09dc4bb0e386c4ea3edd6e111b388ec3d5
 2: Black / Navy | P #151619 | S #172B55 | T #294B82 | Q #252B35 | bridge56 #151C2B | SHA256 e7c6c8d46d9e9ef412e4e678c0aa14031bea0687b9c41d89e137ca4ae47315d8
 3: Emerald / Brown | P #137A52 | S #6B4327 | T #9A673A | Q #70451F | bridge56 #374330 | SHA256 88a43ab2b66b581a097b351af39cad6c818da988a2ca8797b5b08c23b40a38b1
 4: Sky Blue / Cloud White | P #55AEE8 | S #F2F5F7 | T #DCEAF4 | Q #8A6848 | bridge56 #3D87B7 | SHA256 34e273b07c2e1289889b2fabcc42d97017dc113b16d42db0ef002e4153f2c6ae
 5: Cream / Black | P #E8D8B2 | S #17181A | T #8C7654 | Q #4A3528 | bridge56 #545148 | SHA256 4f42bafa7825b049f9a0b394a9cdc61a2474927a3341af5711c3c2eaed005325
 6: Black / Charcoal / Gold | P #151619 | S #41444A | T #D4A62A | Q #8A651F | bridge56 #252629 | SHA256 f66811dce6c7186e459fd1c53b571d5b57b600d65d226a7c5c6574bae28f53cf
 7: Orange / Blue | P #E56D22 | S #245EA8 | T #4A87D3 | Q #493225 | bridge56 #595056 | SHA256 0f4ffe07c60a545f43243458bbf5c9ed4c5d511d4c528c88af2ffa2cd40c1c36
 8: Purple / Black / White | P #6F3FA0 | S #17181A | T #F2F2F0 | Q #343038 | bridge56 #2F243C | SHA256 ab7dd15fd41819ed4d1bb4cb5cf6e86036c6355447969d9b444794d03ec138c6
 9: Charcoal | P #44484D | S #303338 | T #62666B | Q #292B2E | bridge56 #2D2F32 | SHA256 bf9952ce3d83bf5e5679be3ae34cbdcd862b29ba03e1717c7bc2e807b4e6e55c
10: Red / Crimson / Gold | P #B92F35 | S #791B2A | T #D5A42A | Q #5B3320 | bridge56 #67282E | SHA256 8ff70b821978ce1486f61644ab07161e90d272e6bd33f6df3bf85beb6f017aea