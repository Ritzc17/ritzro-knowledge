RitzRO male Acolyte custom palettes v4
Base: acolyte_male_692.pal

Mapping from RitzRO PAL reverse-engineering v0.3:
  Primary: 73-79
  Secondary: 9-15; 56 extra-light highlight
  Tertiary: 49-55
  Quaternary: 1-2; 16-23; 25-31; 65,66,68
  Outline/edge: 43-48, dark/muted derivative
  Belt accessory: 81-89, Secondary-derived
  Preserved: 8; 34,36,37,39,40; 70-72

 1: Black / Crimson | Primary #151619 | Secondary #8E1831 | Tertiary #B21F3D | Quaternary #3B2024 | SHA256 003c27068dd7255a36a9b1e3d643e10ffa5316a8d90ea347f422f04df057b1e5
 2: Black / Navy | Primary #151619 | Secondary #172B55 | Tertiary #294B82 | Quaternary #252B35 | SHA256 d5857a1d7a76e0eca144d7312243c5d7627b9b1f66ccced754aff947552ea14d
 3: Emerald / Brown | Primary #137A52 | Secondary #6B4327 | Tertiary #9A673A | Quaternary #70451F | SHA256 328a967e23455ffbf1f243ed6dc18b64919576b389da443486e0812b9b412396
 4: Sky Blue / Cloud White | Primary #55AEE8 | Secondary #F2F5F7 | Tertiary #DCEAF4 | Quaternary #8A6848 | SHA256 9badbfa7917d4f52b6c48f3481f610b1a8b3b70d390733d23d17ed5992797c81
 5: Cream / Black | Primary #E8D8B2 | Secondary #17181A | Tertiary #8C7654 | Quaternary #4A3528 | SHA256 1a9dbcc702cfd490a311a6302501132725d8a6f076ac89d67e350edeaa9cad2e
 6: Black / Charcoal / Gold | Primary #151619 | Secondary #41444A | Tertiary #D4A62A | Quaternary #8A651F | SHA256 b1a27d192149704bb9f3468bf1a19e2a217eaced6b5330503474cfdcff0b4ef3
 7: Orange / Blue | Primary #E56D22 | Secondary #245EA8 | Tertiary #4A87D3 | Quaternary #493225 | SHA256 93a403ae5cc847e8fe240feb66e2bae5e2d54b1e6a84f8be0f369f2290bcf590
 8: Purple / Black / White | Primary #6F3FA0 | Secondary #17181A | Tertiary #F2F2F0 | Quaternary #343038 | SHA256 812c556478025d9ac25feb2c81bad91eee5e2a63d80377a7f96a3da1d32f26db
 9: Charcoal | Primary #44484D | Secondary #303338 | Tertiary #62666B | Quaternary #292B2E | SHA256 61888de0a571e9db25ece462eb503bb5a08cea8465f739b8c664b594bacbec7d
10: Red / Crimson / Gold | Primary #B92F35 | Secondary #791B2A | Tertiary #D5A42A | Quaternary #5B3320 | SHA256 65f11940e2010e51cedeb4ba825bd8df5dd0b0d92036f3d118511cf36fadace9