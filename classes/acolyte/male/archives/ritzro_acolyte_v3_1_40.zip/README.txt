RitzRO male Acolyte custom palettes v3, 1-40

Generated from the known-good Acolyte v5 binary baseline. Fourth bytes and untouched entries are preserved.

Current Acolyte mapping used:
  Primary robe: 73-79
  Secondary frock: 9,11,12,14,15
  Shared index 56: role-aware Secondary shadow / Primary detail, with selected intentional overrides
  Tertiary cuffs/trousers: 49-55 + 13
  Quaternary gloves/shoes: 1-2,10,16-23,25-31,65,66,68
  Outline: 43-48
  Belt: 81-89, Secondary-derived
  Preserved: 8; 34,36,37,39,40; 70-72

Key v3 design lessons:
  - index 56 is usually a dark Secondary shadow that can also read as a subtle Primary detail
  - index 56 is selected by value role: dark when Secondary is bright, potentially light when Secondary is dark
  - gloves/shoes are not restricted to brown leather; their color is part of the overall composition
  - dark garments retain readable value ramps instead of collapsing to flat black
  - adjacent garment families are separated by hue, value, saturation, or material character

Design groups:
  1-10  reimagined originals
 11-20  grounded / realistic
 21-30  fluorescent experiments with fluorescent Primary robes
 31-40  wild cards

 1: Crimson Cleric       | P #15161A | S #E51F43 | T #F2C23A | Q #7A2634 | 56 #4C1722 | SHA256 04365ff8d3ea2b1b610d83bc29661717e000c7fe2744f24b62ab694b6c66f734
 2: Cobalt Cleric        | P #14161B | S #2478F2 | T #E5B144 | Q #2A4B78 | 56 #132C56 | SHA256 ccfc7123301eebe061d6081aff52e828f523b440acf8fb9083c797e1cae59625
 3: Emerald Pilgrim      | P #137253 | S #79512F | T #D99642 | Q #633A2A | 56 #3C2A21 | SHA256 9342418dad6471fe53127ac3aa34620e5135bd5b535b56e3f70eb94eb1cd5453
 4: Winter Chapel        | P #59AEE0 | S #F6F0E4 | T #5F88A6 | Q #B98355 | 56 #8B8B89 | SHA256 706b2584f362fb0251d1138d9a2952dd1bcd6bbd8f24d95627bab40f8ed8ce59
 5: Ivory Nocturne       | P #E4D1A5 | S #17191D | T #C48B55 | Q #6F3E58 | 56 #343036 | SHA256 b83ce01175206b73e812d688fd64679681c9664f8cb28292b2f0e882f553534e
 6: Gilded Shadow        | P #15171B | S #50545D | T #F1BF28 | Q #9B7421 | 56 #333840 | SHA256 3c046f1c7ef8185b633e4c7a6130acc08f701e7621daeca4ec7d61a7ce415f8c
 7: Azure Ember          | P #B84617 | S #188CFF | T #188CFF | Q #E56E1F | 56 #123F86 | SHA256 6f35ec9b6cc55d98e87dd6da21ffd9e7c894d7c322810abd101be6ab8ddeb55b
 8: Violet Monastic      | P #7043AE | S #17191D | T #D8D5EA | Q #55358C | 56 #2D2934 | SHA256 4616b20302704dd28e269ed46ea39be1a3fbfb62376b7f44999cc88b9b2d4940
 9: True Charcoal        | P #1E2126 | S #4B5058 | T #8E98A4 | Q #A05A3E | 56 #333940 | SHA256 6ca8be9d439f4f3c01fe7d25cf06aa195fd16a0a3c3bda6c3875d91a15df811c
10: Scarlet Reliquary    | P #C63843 | S #951C32 | T #F1C12C | Q #5538A4 | 56 #651928 | SHA256 a8c6b9c80f63c3ddd14ca9047aea38c0d32d4569e156177f3a4827931211b844
11: Forest Parish        | P #4D613E | S #304E3D | T #A77B4E | Q #6B4930 | 56 #263B30 | SHA256 68702be64094f40921a6a11ee5a1ae1c4d2c29556ab437101bd5bd068c5ef42e
12: Desert Friar         | P #B99C6E | S #887150 | T #5D4937 | Q #795B40 | 56 #5B4938 | SHA256 a0340170e545611ca656f49d60a58281da2f1c8bbc950c225fc3507416764412
13: Harbor Chaplain      | P #526E86 | S #31495D | T #C08D55 | Q #7D3F32 | 56 #263B4B | SHA256 b41413f7951da82f6a71763bfcac5dfae22b8365d826e93f4b85df56ff5b542f
14: Burgundy Vestment    | P #2B2E34 | S #7D374B | T #B98361 | Q #3C4D62 | 56 #4A2231 | SHA256 886ee12b43012ef45e5633b7f2cf8a9f2f66bb9adceb829a48bc523cbe8bd2ff
15: Moss and Linen       | P #627057 | S #D7CEB0 | T #866447 | Q #365C55 | 56 #716B57 | SHA256 c2926f355c002c1bd32fbc7b67b1c0500d1e373171a6894ab7452af1e9a30329
16: Slate Missionary     | P #2C3138 | S #60798C | T #B1845E | Q #6C3C2F | 56 #3C5262 | SHA256 e6a9e539fc029bedd227b5e2f51b92b1ffbb9ba27568182639d15ba7f6c42245
17: Autumn Parish        | P #685F41 | S #A55230 | T #65412E | Q #425C35 | 56 #653220 | SHA256 b35b7dea4312f2b849bb647eed9d04d80f4002f6ccb7eba227a4aa0f65898ce9
18: Dust Road            | P #877A6A | S #72836B | T #B47A4A | Q #4E6570 | 56 #4F5B49 | SHA256 258a7abe23b395a378ef68405b80b12da8f4e4ecd5f6be5c3a5d186a431d8114
19: Cold Abbey           | P #27394F | S #5B6067 | T #B88D61 | Q #764539 | 56 #35404E | SHA256 8c45c2ce85353a670a454b52051e37510332ea226d2cfde852d91831260f4c18
20: Field Cleric         | P #725842 | S #606B43 | T #3A3D42 | Q #8E6D38 | 56 #3D492F | SHA256 2700e039033d33f149abbac9224de2772e1a922bca4a29e8c8b600b9babc7b93
21: Neon Cyan Rite       | P #00DDEB | S #151822 | T #FF35B4 | Q #FF7A21 | 56 #4A1740 | SHA256 db1f082176102e0b0dda64b457453186c760c3a40ea5199144354a5916ef956a
22: Acid Magenta         | P #F229C5 | S #29123A | T #B7FF1F | Q #7040FF | 56 #C8B8E8 | SHA256 f7bc4e668ddf9bbda9c866e603f2c2e2330f116808db6a23e2906a74defa1d40
23: Toxic Lime           | P #A8F21C | S #16221A | T #7A35FF | Q #FF4B29 | 56 #304C24 | SHA256 0a5d9070b97bdae751cfec9e9fdc5074173f4fa5e1bd6417fc6d55a67d59aac8
24: Ultraviolet          | P #8A42F4 | S #00CFE8 | T #FF7A18 | Q #FF4DAA | 56 #075060 | SHA256 d4b06d0f2630d341f2cfe54b5be3b2c38a60b3bef6ac1668f46ceda67a7f0fab
25: Laser Orange         | P #FF6B1A | S #171515 | T #17F0D1 | Q #7B46FF | 56 #D8D1C8 | SHA256 102a264ee42dae932383f88c44da22a7171fa36ca31bff72e512f913db3428d7
26: Electric Blue        | P #168BFF | S #F1E719 | T #FF35A8 | Q #FF682C | 56 #625C12 | SHA256 05889bcfe5d1418a2ef4cc118a5ecddae576e476f437e4bd6e1160619a55bef6
27: Radioactive Rose     | P #FF347B | S #24202E | T #7CFF35 | Q #21D8FF | 56 #5A1730 | SHA256 233d680e6e311ba4dbb52718e77e6e11fc43858c877e2f300efc810db9e43047
28: Plasma Violet        | P #B323FF | S #00E7E0 | T #FF7A18 | Q #7DFF42 | 56 #075452 | SHA256 ed48c36c39f2973dc3124ede019065f6ffd9b0d5963177ae6afa920d8ca6af0f
29: Signal Green         | P #25EF83 | S #40205B | T #FF2D59 | Q #43C8FF | 56 #C6A6D6 | SHA256 334c425a6e96aefd6331c24f88b5f9370e1c4d36e2d7610b8900fa355ab7bc99
30: Cyber Yellow         | P #F3ED21 | S #162B51 | T #FF3B9B | Q #45FF87 | 56 #233D69 | SHA256 9be4fb325324483ca059af43cd645a3f432b26d268890582ba9c60b8f6515caa
31: Royal Peacock        | P #00A7A0 | S #4A35D4 | T #FFD447 | Q #E849A6 | 56 #241B68 | SHA256 60795ad40e1f9640576113e4cdf96aa3c5905a1edd45ea346effcededf9a0ca3
32: Blood and Bone       | P #7D1023 | S #E7D9B7 | T #2A2A31 | Q #5D91D8 | 56 #5A4A3D | SHA256 31b5a72653c0bc3649d395ae8e9778106e84769793e3c5a21d5380f94eacd9b8
33: Copper Storm         | P #D66B2F | S #304E72 | T #55E2D1 | Q #F2C63B | 56 #1E3B59 | SHA256 cb581756b6269d6163491be17b85945d6de9420e029e59c0eb968b501dd4f92e
34: Moonlit Orchid       | P #6A35B8 | S #E08BD5 | T #26233C | Q #36C7B5 | 56 #632F63 | SHA256 e5d96fdafbab4766df477fa9e5fd51c3e715b8cca4c93bd42febafe4df367c2f
35: Jade Ember           | P #0D8B73 | S #FF552A | T #F4D14C | Q #376FE8 | 56 #712516 | SHA256 cb339ce3cb140d976e0459bd28fc82bd0a70d0457800995a29d1b9274a36211b
36: Rose Gold Night      | P #D15882 | S #15161B | T #F0B06A | Q #28D2C6 | 56 #3B3036 | SHA256 baf094eccc5b6b56330897fe736d58f467d89eb92a8de68d9a808f39e4e190b2
37: Icefire              | P #76DDF4 | S #F05A36 | T #172333 | Q #FFBF24 | 56 #74291C | SHA256 0044a8c138ead7230c9c4efa605e3d6f835b600ba224cb015577efbd3a6c01c3
38: Teal and Wine        | P #1D777A | S #8C315B | T #F0B54A | Q #3D63C8 | 56 #4C2235 | SHA256 a4e2f976c391bed2765ebd5c68fb5d4741b2964488eb3e132e27ea6501d41df5
39: Solar Punk           | P #B5E331 | S #152F28 | T #19D7AD | Q #FF5C4C | 56 #244A3D | SHA256 23b8240e022b36c3f571aa79eb7121555c96b70fd5b4eeb1c866f97d4093a748
40: Black Hot Pink       | P #101014 | S #FF2998 | T #272832 | Q #FF2998 | 56 #66163F | SHA256 79125a44e4642f2a791a592dc227193dd1d45b04649a09d81371116b56d5d856
