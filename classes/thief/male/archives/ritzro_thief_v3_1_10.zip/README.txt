RitzRO male Thief custom palettes v3
Base: thief_male_4.pal

v3 changes:
  indices 9 and 10 are now Secondary jacket highlights.
  index 10 is the brighter highlight; index 9 is slightly more restrained because it is more widely reused.
  Primary pants for styles 1 and 2 were lightened from near-black so ramp detail remains visible.

Semantic model:
  Primary pants: 16-23
  Secondary jacket highlights: 9,10,57-63
  Secondary jacket main/shared boot-tip range: 72-79
  Tertiary gloves/shoes: 24-39
  Quaternary rear/back boot panels: 64-71
  Accessory undershirt: 40-47
  Accessory kneepads: 48-55

 1: Black / Crimson | P #2A2D32 | S #8E1831 | T #B21F3D | Q #3B2024 | idx9 #CE2347 | idx10 #DE3C5E | SHA256 8d5e1cd2039f3910842990c60adfe6fe79037f86ad7b523f7e5dbd6ac62982dd
 2: Black / Navy | P #2B2F36 | S #172B55 | T #294B82 | Q #252B35 | idx9 #213E7B | idx10 #274990 | SHA256 5caad8474541433a9c5cfc045416758d2079da6388a10af9aa553dd046cfab85
 3: Emerald / Brown | P #137A52 | S #6B4327 | T #9A673A | Q #70451F | idx9 #9B6139 | idx10 #B67242 | SHA256 522b4fa487c3bfb720345f04ef45ff883a95f3061cb020835f6f6123f2b5abde
 4: Sky Blue / Cloud White | P #55AEE8 | S #F2F5F7 | T #DCEAF4 | Q #8A6848 | idx9 #FFFFFF | idx10 #FFFFFF | SHA256 d62b1edc2227fa7dad724a4e4faf47ee36ff8c44ad4b169604f9f74a97cdf6bf
 5: Cream / Black | P #E8D8B2 | S #17181A | T #8C7654 | Q #4A3528 | idx9 #212326 | idx10 #27292C | SHA256 31a6f1f924ddf3e1174337c44bd4a9162461ae0d298571a5aaf468b4a6891414
 6: Black / Charcoal / Gold | P #151619 | S #41444A | T #D4A62A | Q #8A651F | idx9 #5E636B | idx10 #6E747E | SHA256 cae6f0528f136d033eb7204b33837530f71a1c18a5c9104c71bb90e5f09ef124
 7: Orange / Blue | P #E56D22 | S #245EA8 | T #4A87D3 | Q #493225 | idx9 #4F8BD9 | idx10 #79A7E2 | SHA256 6a9a46a92933c9d1bfa17c8577ca4eadf268063c89ea49234d808674892a7062
 8: Purple / Black / White | P #6F3FA0 | S #17181A | T #F2F2F0 | Q #343038 | idx9 #212326 | idx10 #27292C | SHA256 9f47e3b9be82de6e3da746fad8ec53db4760ed05a10942495ff4e87c798c7573
 9: Charcoal | P #44484D | S #303338 | T #62666B | Q #292B2E | idx9 #464A51 | idx10 #52575F | SHA256 3dcbcc694df60fcf26451f2e85809482db62aeff5f6cfd1cb7b9283f7b212597
10: Red / Crimson / Gold | P #B92F35 | S #791B2A | T #D5A42A | Q #5B3320 | idx9 #AF273D | idx10 #CE2E47 | SHA256 14aa9c59a75f3974244c8d690578de4b3de103687e510f7b91ed1bcc9585a000