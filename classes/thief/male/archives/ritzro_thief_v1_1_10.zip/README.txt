RitzRO male Thief custom palettes v1
Base: thief_male_4.pal (first clean stock palette)

Semantic model derived from direct SPR masks + diagnostics:
  Primary pants: 16-23
  Secondary jacket: 72-79
  Tertiary gloves/shoes: 24-39
  Quaternary rear/back boot panels: 64-71
  Accessory white undershirt: 40-47

Important preservation choices:
  9-15 are preserved: direct atlas + stock colors indicate exposed skin/skin-related pixels.
  48-55 and 57-63 are preserved in v1 pending stronger semantic classification.
  Other untouched used indices remain exactly as palette 4.

 1: Black / Crimson | P #151619 | S #8E1831 | T #B21F3D | Q #3B2024 | Accessory #E8E1DD | SHA256 a049d573e72c82bfc346d5bafc95e5627bf368838bfbb48081932ace93c641f7
 2: Black / Navy | P #151619 | S #172B55 | T #294B82 | Q #252B35 | Accessory #DDE4EE | SHA256 869bd7dbd40e4fcbfb213b8931dc4eab745ca0521375aa45892488593bd013b5
 3: Emerald / Brown | P #137A52 | S #6B4327 | T #9A673A | Q #70451F | Accessory #E8DFC9 | SHA256 0b5d81545403684b5f4df55464678aedd8d61f46eb226559426d788af390988b
 4: Sky Blue / Cloud White | P #55AEE8 | S #F2F5F7 | T #DCEAF4 | Q #8A6848 | Accessory #FFFFFF | SHA256 edd30bd50bde3ad21310b72cf94398221c9a0eb68f03ace900d0c96b5c67530c
 5: Cream / Black | P #E8D8B2 | S #17181A | T #8C7654 | Q #4A3528 | Accessory #F5EFE2 | SHA256 8b47cb7b0c19ba4388d23dc846c6330fcdec8c1d730e55eb36791158cf2e5b3d
 6: Black / Charcoal / Gold | P #151619 | S #41444A | T #D4A62A | Q #8A651F | Accessory #E7D8AE | SHA256 518f5702cc2c15d52a4b3c39a6ef5b0f505be874f3c52ee5e2a3f1a444471ccd
 7: Orange / Blue | P #E56D22 | S #245EA8 | T #4A87D3 | Q #493225 | Accessory #F1E5D2 | SHA256 160fc77e51df2f08db310aa34dd35bc7185729cc2683ca31f01c0b2d341be9b6
 8: Purple / Black / White | P #6F3FA0 | S #17181A | T #F2F2F0 | Q #343038 | Accessory #F3F0F5 | SHA256 aae271a6558df48cb0f6126fcf5201197df6f5825e9155eaa2c94d40d0805e05
 9: Charcoal | P #44484D | S #303338 | T #62666B | Q #292B2E | Accessory #D9DADD | SHA256 74c8020a84c3e9fc240f57f58de3ef88f03029930e290223b7f3de0374dc3474
10: Red / Crimson / Gold | P #B92F35 | S #791B2A | T #D5A42A | Q #5B3320 | Accessory #F0DFBE | SHA256 5f2dab17917b58952a925065498de34e41686a670948576af98c62767669f9ae