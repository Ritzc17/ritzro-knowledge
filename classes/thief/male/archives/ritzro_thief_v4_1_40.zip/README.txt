RitzRO Male Thief palettes v4 (1-40)

Mapping: 16-23 pants; 41 waistband highlight; 9/10,57-63,75-79 jacket; 24-31 equipment A; 32-39 equipment B; 72-74 footwear detail; 40 undershirt/jacket bridge.

Design pass: 1-10 stronger saturation/pop; 11-20 realistic/muted with varied equipment and several single-tone equipment schemes; 21-30 fluorescent/high-saturation; 31-40 wildcards; 40 black + hot pink.

Themes:
01 Scarlet Rider | pants #15171b | jacket #f0182f | equipment A #f0a12e | equipment B #6e1725 | undershirt #d8d9dc
02 Cobalt Night | pants #141820 | jacket #075cff | equipment A #d99531 | equipment B #14284f | undershirt #e2d5b8
03 Forest Wine | pants #08704c | jacket #8a4a31 | equipment A #a72858 | equipment B #3a201a | undershirt #e2cdb8
04 Winter Sky | pants #38aee8 | jacket #fffaf0 | equipment A #2c6384 | equipment B #d1a26a | undershirt #d9f2ff
05 Cream Noir | pants #ead6a4 | jacket #111217 | equipment A #b46a9d | equipment B #3a2030 | undershirt #f3e5d1
06 Gilded Shadow | pants #101217 | jacket #111318 | equipment A #ffd02e | equipment B #8b5b0d | undershirt #d8b94f
07 Wayfarer | pants #f07818 | jacket #075fd1 | equipment A #ff8b12 | equipment B #743219 | undershirt #e7d4b7
08 Nightshade | pants #742eb6 | jacket #111017 | equipment A #72d8ed | equipment B #3a174f | undershirt #d7bdf4
09 Ash Rogue | pants #111318 | jacket #2b3038 | equipment A #9aa4b2 | equipment B #191c22 | undershirt #c6ccd2
10 Red Mercenary | pants #a51020 | jacket #ef2036 | equipment A #ffd029 | equipment B #5a1b18 | undershirt #d9c7b8
11 Ranger | pants #65713c | jacket #315c3c | equipment A #b77a48 | equipment B #b77a48 | undershirt #d7cfb3
12 Desert Scout | pants #b8a373 | jacket #c29b62 | equipment A #667f90 | equipment B #667f90 | undershirt #e7dbc0
13 Dockworker | pants #536f86 | jacket #344d65 | equipment A #b65d45 | equipment B #7f3f32 | undershirt #d9d1c3
14 Burgundy Leather | pants #25282e | jacket #6d263e | equipment A #718ba0 | equipment B #718ba0 | undershirt #c8c1bb
15 Mountain Hunter | pants #5e6c43 | jacket #74746d | equipment A #a75d38 | equipment B #4d3528 | undershirt #d8d0bd
16 Urban Rogue | pants #15171c | jacket #41647f | equipment A #b56e3d | equipment B #b56e3d | undershirt #c8d0d4
17 Autumn Scout | pants #766f3b | jacket #a34b26 | equipment A #47704b | equipment B #47704b | undershirt #d5c6aa
18 Dusty Traveler | pants #88786b | jacket #708169 | equipment A #a65d76 | equipment B #6b394e | undershirt #d9d0c7
19 Cold Weather | pants #233651 | jacket #494c54 | equipment A #b99155 | equipment B #b99155 | undershirt #c8d0d8
20 Field Mercenary | pants #66503b | jacket #59643a | equipment A #527287 | equipment B #334b5b | undershirt #d4ccb8
21 Poison Dart | pants #00f0dc | jacket #6926ff | equipment A #ff27aa | equipment B #11131b | undershirt #d9fffb
22 Inferno | pants #24131a | jacket #ff4a00 | equipment A #ffe21f | equipment B #b50032 | undershirt #fff0b0
23 Arcane Thief | pants #5c16d8 | jacket #a018ff | equipment A #00f4ff | equipment B #171443 | undershirt #e7c7ff
24 Blood Moon | pants #090a0d | jacket #f0003c | equipment A #fff0c9 | equipment B #63001f | undershirt #d8d8d8
25 Tropical Venom | pants #00e5d8 | jacket #baff00 | equipment A #a700ff | equipment B #063c46 | undershirt #d9ff72
26 Royal Outlaw | pants #7a20d8 | jacket #005dff | equipment A #ffe100 | equipment B #a71968 | undershirt #efe1ff
27 Rose Assassin | pants #111117 | jacket #ff1684 | equipment A #ff9dcb | equipment B #720044 | undershirt #ffe0ef
28 Frostbite | pants #062a68 | jacket #4fdcff | equipment A #effcff | equipment B #0b3673 | undershirt #d7f8ff
29 Phoenix | pants #7b0926 | jacket #ff2517 | equipment A #ffe018 | equipment B #ff7200 | undershirt #fff0a0
30 Spectral Rogue | pants #101218 | jacket #00ffe7 | equipment A #c37aff | equipment B #292071 | undershirt #d9fffb
31 Black Citrus | pants #0c0d11 | jacket #e9ff20 | equipment A #ff6412 | equipment B #14151a | undershirt #f5ffb0
32 Emerald Cream | pants #006a48 | jacket #fff0c4 | equipment A #20e69a | equipment B #66422a | undershirt #d9fff0
33 Violet Cyan | pants #6015a0 | jacket #00e8ef | equipment A #e91fff | equipment B #082d3a | undershirt #ead6ff
34 Copper Ice | pants #9d3f18 | jacket #74eaff | equipment A #ff8b25 | equipment B #234c68 | undershirt #d8fbff
35 Navy Gold | pants #09265f | jacket #ffbd00 | equipment A #176aff | equipment B #6d4200 | undershirt #fff0aa
36 Neon Duel | pants #101116 | jacket #7730ff | equipment A #ff1e9a | equipment B #00eaff | undershirt #e2d7ff
37 Toxic Sunset | pants #6a1594 | jacket #ff5200 | equipment A #baff00 | equipment B #143d22 | undershirt #f2ff9e
38 Cherry Mint | pants #861536 | jacket #20eaa1 | equipment A #ff315a | equipment B #0a4939 | undershirt #d5fff0
39 Solar Punk | pants #143d35 | jacket #fff000 | equipment A #00e5dc | equipment B #a5009e | undershirt #efffb0
40 Hot Pink Shadow | pants #0b0c10 | jacket #0b0c10 | equipment A #ff1493 | equipment B #250016 | undershirt #ff4faf

SHA256:
thief_male_1.pal  a1c52ba11210389b1cdbf5875a6ce31f0c44f8dea5c5e50447adf21c39ca5169
thief_male_2.pal  9dea62ec4ab5763b868de48fe6f86f54ad6da6c0cf06b83523e00f3da0ddd863
thief_male_3.pal  c177ef91bbfd5fb85a24a37119add3830e4d0f07267a4ed45907e22e271ad6ed
thief_male_4.pal  79f8c31dbc0afbf60f18bb44dc88220a59e9ce73f41ea745542eb1dba5ecf1dd
thief_male_5.pal  e2998093a25342c6e47f7b25745ee2166121717304403ec0fa66333710a6f9ce
thief_male_6.pal  4a71eeaa8518f025d5add103dd5860bcce16beaeb5c9e7873941b7fa7b3bffae
thief_male_7.pal  ecae9cdbe5c7aaca729efd0c01ded26d938d51dbb7415a74c267d7190bbc6f0b
thief_male_8.pal  19a9c07986c31174bfaed2bd28fd8ecc45f800c035561bc50059fb2710419ede
thief_male_9.pal  0467da20e5e378ff50e0ccda0a6981fb44aea9247b92061328187eb96187da85
thief_male_10.pal  32c1f24de3baa7c49660ffbe6d702da96e6cc27db35fe7c1faea9c3c7a65f77f
thief_male_11.pal  cb3c768843252cd43465f3c1a48acaed7a9e295df7cd8d435cb1e6b8f0cee8e4
thief_male_12.pal  b4e48c6ad77894e57ccc3be668312e7acf4290480b33213c9423e1661d6f313a
thief_male_13.pal  b9143c27c0f5efa6cbbc30d47e7ec4fad580655f19412054b855bfcd286aa711
thief_male_14.pal  8240dced82c8392cd37d83012a607c8c1331e08581aeded124e09356911d47c6
thief_male_15.pal  52a88607bbb30ac3470bbf1005734d5cd40a7098b32f0e98e0bb2f0a77bf8aaa
thief_male_16.pal  2ff5f0b5d26af709ef5a42314439aa4046289f4a11bf1daf8c806835c60a0e82
thief_male_17.pal  33b71d1de626f0ad60eb8e6f1a30be08aac8406744aec167aa1ca5c9a2fed52a
thief_male_18.pal  c9e8d96ffa716f866a71d4902e3aded8da8a1327b3d38bf949955a2a68aaaf0d
thief_male_19.pal  99247ef821092a0c0f8228f28effd9ade36d02b1a40d049b70949c329345883f
thief_male_20.pal  f9f3dfc02a0f2999ba14733b5aaa4431bd0270bd843ebccb8b6bd628064e2f67
thief_male_21.pal  ca13aa42fdacc2284a8a97c18c154a12263cacae583782e5bcd890de388a6433
thief_male_22.pal  955fdd5c0f18e4d94d0353ce14c6543187d22c8bf26cb77e7b65a7cd06134ef2
thief_male_23.pal  d69805d414c7339d8de58349dfa09defff393d41c2fb168b4e9dccce4b383ad6
thief_male_24.pal  35ea091ae48eb27961c28ac2a192146fcb0f010cf5940a21420dfa2553d51ab4
thief_male_25.pal  b726fd49eb228de5f4385d3d42f5c9e1f24d79d9e280c8a171cdca554b839846
thief_male_26.pal  ca28711d9ee9b9140e95f144dee777182a756bb9ba3c6923b34efdadac4f1fdc
thief_male_27.pal  310710056c5fdb9a24218963b15fab9a04e0471e806ade49225aca643b5e9e58
thief_male_28.pal  25dcecb33896f7579fedb146746a02989244ff27fe75fd05cc8e813c2b2d73f4
thief_male_29.pal  eb15f1e9a8a1ba5e98b447d6c7a04d14272119057288f9ccc84201307147f6c9
thief_male_30.pal  f33ef77e106d777080c81017276c3d1721c932bf19dcf318825abf1418efc5df
thief_male_31.pal  ec23fa48809a9e45dc780aa5dc56be34773dc9bf7993d2768420fbc4010907ee
thief_male_32.pal  d443df73446524d3232e9a9116869729e4388b478763bbf3d4cac54183620545
thief_male_33.pal  df6b19f6864c7b19af8fb842790cf3149435f6e6184ab8c04c195738c1ef13b9
thief_male_34.pal  e7ab17da8eec844d3d451afc9c46eff19287498280d89b69a96e20c791194c35
thief_male_35.pal  fc10f88939680b432f57f7c85e8b79ad36ca7d66dfc947c8e061be6f81794eeb
thief_male_36.pal  7efa755c2551bfbf6e4205b424ef2b2505029b6763b92effbaf84d02fd64cd57
thief_male_37.pal  b3601ea2f2a9370cd75b2fbebe7aeebe5a29c9664f68b28ffb16a5e556e785e0
thief_male_38.pal  6b48df48920d483afbf3f407ff852a790f8a30bd42a1aa8dbd264a243dba829e
thief_male_39.pal  24d8e39e5c46d22050ba9ada55274a410af8b9375ab5c86c20f39e1d7e5950c5
thief_male_40.pal  ffd42f97daed219c437f18754f049d9c8d3cd7d38aefa4b311db53b2ce548221
