RitzRO male Thief diagnostics round 2 (11-15)
Base: thief_male_4.pal (first clean in-game Thief palette)

11: 9-15 individually mapped
12: 16-23 individually mapped
13: 24-31 individually mapped
14: 32-39 individually mapped
15: 64-71 GREEN; 72-79 CYAN

Color order for 7-entry map (11):
  9 -> RGB(255, 255, 255)
  10 -> RGB(255, 255, 0)
  11 -> RGB(0, 255, 0)
  12 -> RGB(0, 255, 255)
  13 -> RGB(0, 0, 255)
  14 -> RGB(255, 0, 255)
  15 -> RGB(255, 0, 0)

Color order for 8-entry maps (12-14):
  slot 0 -> RGB(255, 255, 255)
  slot 1 -> RGB(255, 255, 0)
  slot 2 -> RGB(128, 255, 0)
  slot 3 -> RGB(0, 255, 0)
  slot 4 -> RGB(0, 255, 255)
  slot 5 -> RGB(0, 0, 255)
  slot 6 -> RGB(255, 0, 255)
  slot 7 -> RGB(255, 0, 0)

11: 9-15 individually mapped
    SHA256 0e254b3390fe55df670baa0a5d0eb22c4b296b5f94a19c0015fbfab43f2ace14

12: 16-23 individually mapped
    SHA256 bf296cbb3a0d09bc48d6158e6719107f21a31a5e1e1027c9330890ce35aec7d4

13: 24-31 individually mapped
    SHA256 edc113f29fc365aeacab08e88f13efe606ad395be37258fdaa139066b8ea248b

14: 32-39 individually mapped
    SHA256 abc55a8e56b04c961aa8b17e0bb0cf99663e8d37388d3ce51a9266fa93f87bf5

15: 64-71 GREEN; 72-79 CYAN
    SHA256 9f80c0e092c99ce849a2b3ac6806c3f495c0b507ee40cfd1c2aa7f29657db973