RitzRO male Thief broad palette diagnostics 11-15
Base: thief_male_0.pal

Purpose: establish class-specific clothing/skin/accessory families before generating the ten RitzRO styles.

11: 40-55 -> RED
    SHA256 033c10a65be14309507fde973c08936beb407e399ae4c2a7955d04c30861e84c
12: 64-71 -> GREEN
    SHA256 5fd9f935e33cdd50a759789d820f9de7821c48cea560171f83462cebd8d28887
13: 72-79 -> CYAN
    SHA256 5a95332e2af4a0a52932b5baa3b4d6b6d1c3cfd9b8ccb4cbe7901d86b42c2044
14: 16-39 -> MAGENTA
    SHA256 ccc732ddde429b1dfc1a18ffe7c281bf5b642e6f9f69b7f9f33e0f6ab5b74d86
15: 9-15 -> YELLOW
    SHA256 1c0ba2bac59340dbe0aa587fe539834ba0789c1031c29062f24c0cbeb5b0654b