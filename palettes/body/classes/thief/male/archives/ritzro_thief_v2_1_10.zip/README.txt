RitzRO male Thief custom palettes v2
Base: thief_male_4.pal

v2 semantic model:
  Primary pants: 16-23
  Secondary jacket supplemental/highlights: 57-63
  Secondary jacket main: 72-79
  Tertiary gloves/shoes: 24-39
  Quaternary rear/back boot panels: 64-71
  Accessory undershirt: 40-47, very light coordinated hue
  Accessory kneepads: 48-55, contrasting leather-derived hue

Shared jacket/boot-tip handling:
  72-79 are still treated as the main Secondary ramp because they dominate the jacket.
  Their generated ramp is moderated toward Tertiary when Secondary and Tertiary differ,
  reducing conspicuous boot-tip color contamination while retaining jacket identity.

 1: Black / Crimson | P #151619 | S #8E1831 | T #B21F3D | Q #3B2024 | undershirt #E0D5D8 | kneepad #5C202B | shared72-79 #8A283C | SHA256 35801bdea6b7b35c630fc3b40d09c0d7cc0f81e42d3d706686acc3377d148d7b
 2: Black / Navy | P #151619 | S #172B55 | T #294B82 | Q #252B35 | undershirt #D5D7DB | kneepad #26344B | shared72-79 #24365A | SHA256 f73079d27814af367dac0215d8adba8503321fd6c89095ba151ab45ad1744d89
 3: Emerald / Brown | P #137A52 | S #6B4327 | T #9A673A | Q #70451F | undershirt #DCE2DC | kneepad #7C4F27 | shared72-79 #704E35 | SHA256 1ccc06ba4abddf6ca874a2d9100f2f34af9fd4b33f7f5adb0505d590f2e8d150
 4: Sky Blue / Cloud White | P #55AEE8 | S #F2F5F7 | T #DCEAF4 | Q #8A6848 | undershirt #EFF7FC | kneepad #A18C78 | shared72-79 #A3BBCC | SHA256 9f1c91bb93dd57e11dbd986917a02ae2c496110f14aa8906958358b82dec13a7
 5: Cream / Black | P #E8D8B2 | S #17181A | T #8C7654 | Q #4A3528 | undershirt #E8E7E3 | kneepad #5C4734 | shared72-79 #36322C | SHA256 df875202df1fe7c1a720d9e8cbc68a9a5e4adbc761784698da1a344bf26a37b3
 6: Black / Charcoal / Gold | P #151619 | S #41444A | T #D4A62A | Q #8A651F | undershirt #D9D9DA | kneepad #9F7722 | shared72-79 #665D46 | SHA256 1b33f45af799dc31f87046e0c895d587b6a14df74249d60080a0a0caf3551cee
 7: Orange / Blue | P #E56D22 | S #245EA8 | T #4A87D3 | Q #493225 | undershirt #E9E3E3 | kneepad #494A56 | shared72-79 #3D6BA5 | SHA256 7e018cf64d36c2a9194305f8497c5c8433ef2030c1e3c943ceb703b8d13bb42e
 8: Purple / Black / White | P #6F3FA0 | S #17181A | T #F2F2F0 | Q #343038 | undershirt #DDD9E2 | kneepad #69666C | shared72-79 #545556 | SHA256 b72e6fb6c94d1411d10a657e0d02d73c17bb0fd542da8d3e8a32f8a7ff91dc72
 9: Charcoal | P #44484D | S #303338 | T #62666B | Q #292B2E | undershirt #DCDCDD | kneepad #393C3F | shared72-79 #3F4145 | SHA256 749328d197e1fc0b8757cb4db73482c3ed2bb500fb68d0f11039729484e8d40e
10: Red / Crimson / Gold | P #B92F35 | S #791B2A | T #D5A42A | Q #5B3320 | undershirt #EDD8DA | kneepad #7D5323 | shared72-79 #874836 | SHA256 176035843e3ead047a56ec40c596a1778f195807c668e9949bd3e7f9bc8720f4