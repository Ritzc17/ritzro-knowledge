RitzRO Male Thief palettes v3 (1-40)

Mapping: 16-23 pants; 41 waistband highlight; 9/10,57-63,75-79 jacket; 24-31 equipment A; 32-39 equipment B; 72-74 footwear detail; 40 undershirt/jacket bridge.

Themes:
01 Scarlet Rider | pants #17191d | jacket #e52b32 | equipment A #d8862f | equipment B #5b1d24
02 Cobalt Night | pants #171a22 | jacket #1769e0 | equipment A #e09a3e | equipment B #15233f
03 Forest Wine | pants #176044 | jacket #7a4935 | equipment A #8c294b | equipment B #3c261e
04 Winter Sky | pants #5a9fc4 | jacket #f0e8d5 | equipment A #c78c4b | equipment B #6d4931
05 Cream Noir | pants #d8c7a0 | jacket #171719 | equipment A #8d5b7d | equipment B #3d2730
06 Gilded Shadow | pants #15171b | jacket #383b42 | equipment A #e0b83f | equipment B #73511e
07 Wayfarer | pants #d26a22 | jacket #175db8 | equipment A #e58a24 | equipment B #56311f
08 Nightshade | pants #5d2f88 | jacket #17161c | equipment A #67b8c8 | equipment B #34243f
09 Ash Rogue | pants #202329 | jacket #444952 | equipment A #9a6a45 | equipment B #111317
10 Red Mercenary | pants #8f1f27 | jacket #d22b36 | equipment A #e0b23c | equipment B #4b261f
11 Ranger | pants #66713b | jacket #315b3c | equipment A #b37a4a | equipment B #433022
12 Desert Scout | pants #b9a574 | jacket #c4a16d | equipment A #6f8797 | equipment B #4d392b
13 Dockworker | pants #526f86 | jacket #354d65 | equipment A #b35f45 | equipment B #352b29
14 Burgundy Leather | pants #272a30 | jacket #6e263e | equipment A #66839b | equipment B #342125
15 Mountain Hunter | pants #5e6d43 | jacket #74756e | equipment A #a85d38 | equipment B #3b3027
16 Urban Rogue | pants #17191e | jacket #42637d | equipment A #b06d3f | equipment B #25201e
17 Autumn Scout | pants #77703b | jacket #a14c27 | equipment A #476b4a | equipment B #4b3020
18 Dusty Traveler | pants #88796c | jacket #71806a | equipment A #a65d76 | equipment B #4c3932
19 Cold Weather | pants #253651 | jacket #4a4d55 | equipment A #b89055 | equipment B #302923
20 Field Mercenary | pants #66503c | jacket #59643a | equipment A #526f84 | equipment B #3e3325
21 Poison Dart | pants #11d9d1 | jacket #6324d8 | equipment A #ff3ba7 | equipment B #10121a
22 Inferno | pants #17171b | jacket #ff5a16 | equipment A #ffd33d | equipment B #9e1727
23 Arcane Thief | pants #5121a8 | jacket #8d31ff | equipment A #22e6ef | equipment B #16183c
24 Blood Moon | pants #17151b | jacket #d7193f | equipment A #eee0bd | equipment B #5b1427
25 Tropical Venom | pants #0ebfc2 | jacket #b8f21c | equipment A #8d32d5 | equipment B #123b47
26 Royal Outlaw | pants #6730b8 | jacket #195fe0 | equipment A #ffd23d | equipment B #7a244c
27 Rose Assassin | pants #17171c | jacket #f02d83 | equipment A #ff9ac2 | equipment B #6a183d
28 Frostbite | pants #152b58 | jacket #62d8ff | equipment A #d9f2ff | equipment B #1a315d
29 Phoenix | pants #6b1e2d | jacket #f12e24 | equipment A #ffd12f | equipment B #d75b1e
30 Spectral Rogue | pants #15171d | jacket #4ff3e8 | equipment A #b586ff | equipment B #24205c
31 Black Citrus | pants #17181c | jacket #e8e34a | equipment A #ff6a1f | equipment B #202328
32 Emerald Cream | pants #194b39 | jacket #e8dfbd | equipment A #30c987 | equipment B #604936
33 Violet Cyan | pants #47266f | jacket #19c9d2 | equipment A #b93cff | equipment B #132d3b
34 Copper Ice | pants #7d3d22 | jacket #8ee8ff | equipment A #e98135 | equipment B #344a5d
35 Navy Gold | pants #182b55 | jacket #d7aa24 | equipment A #2f65df | equipment B #5a4315
36 Neon Duel | pants #202126 | jacket #7846e8 | equipment A #ff3aa7 | equipment B #16d8e5
37 Toxic Sunset | pants #5b2b72 | jacket #ff6a1d | equipment A #b7f21b | equipment B #283520
38 Cherry Mint | pants #651f36 | jacket #37d9a0 | equipment A #ff526e | equipment B #173e37
39 Solar Punk | pants #28403b | jacket #e7d934 | equipment A #16c7c5 | equipment B #7c2d74
40 Hot Pink Shadow | pants #15161b | jacket #1e2028 | equipment A #ff3f9f | equipment B #7a164d