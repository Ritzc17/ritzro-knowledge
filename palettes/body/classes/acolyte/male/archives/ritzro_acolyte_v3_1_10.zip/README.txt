RitzRO male Acolyte custom palettes v3
Base: acolyte_male_692.pal

v3 model:
  Primary major ramp: 73-79
  Primary supplemental highlight: index 56
  Secondary ramp: 9-15
  Tertiary ramp: 49-55
  Index 72 left unchanged pending stronger semantic evidence.
  Fourth byte preserved for every modified entry.

Index 56 is set to the same brightest Primary shade as index 73.

 1: Black / Crimson | primary #151619 | secondary #8E1831 | tertiary #B21F3D | index56=(30, 32, 36) | sha256 3c23c309c713be56bd317442b1c17ba62567ce972dffa0afbad02f90e7625775
 2: Black / Navy | primary #151619 | secondary #172B55 | tertiary #294B82 | index56=(30, 32, 36) | sha256 b64078aeea108b2a366cfa01626e3f684fa66c98929f7895d7e48b334ccd8e1a
 3: Emerald / Brown | primary #137A52 | secondary #6B4327 | tertiary #9A673A | index56=(28, 177, 119) | sha256 ebaaa387cb55bf8a71c678e09318e120e6c1f63ee3ae0feca18ce95ba32a231f
 4: Sky Blue / Cloud White | primary #55AEE8 | secondary #F2F5F7 | tertiary #DCEAF4 | index56=(211, 234, 249) | sha256 99fd514734c122b2fbd25986691e7834d682ba6fd0b37a3f01cd364d1f4258e8
 5: Cream / Black | primary #E8D8B2 | secondary #17181A | tertiary #8C7654 | index56=(255, 255, 255) | sha256 9d3d18e480c8716b7157c522511ed322d984ba6dabecdde59d09824752b84c2e
 6: Black / Charcoal / Gold | primary #151619 | secondary #41444A | tertiary #D4A62A | index56=(30, 32, 36) | sha256 d4d3e22579cbd76bf2f529ce9d41bf397ba861dbab2e998771baab42ff111937
 7: Orange / Blue | primary #E56D22 | secondary #245EA8 | tertiary #4A87D3 | index56=(241, 179, 140) | sha256 9fb3bb0657c070cae0877c5f58e1a4457f0cc6fa6ca9cb5c55c50bacfec25df6
 8: Purple / Black / White | primary #6F3FA0 | secondary #17181A | tertiary #F2F2F0 | index56=(161, 121, 202) | sha256 864c57a146e132a268316042afc3d34cf598e02d44e2ce657dfa29d59f36e45f
 9: Charcoal | primary #44484D | secondary #303338 | tertiary #62666B | index56=(99, 104, 112) | sha256 f67f019ac071964bf84cf1a6c5b39059c6d1167ebff58169367a2834c42ec6ae
10: Red / Crimson / Gold | primary #B92F35 | secondary #791B2A | tertiary #D5A42A | index56=(220, 117, 121) | sha256 f8b9805436231775c1b0433a29daeb9ee49418043cb9fc4dc828c51a13c1eca4